namespace ListBox
{
    public partial class Form1 : Form
    {
        int maximum = 7;
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random x = new Random();
            listBox1.Items.Clear();
            for (int i = 0; i < maximum; i++)
            {
                int a = x.Next(1, 39);
                listBox1.Items.Add(Convert.ToString(a));
            }
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            int i = listBox1.SelectedIndex;
            string s = listBox1.Items[i].ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i = listBox1.SelectedIndex;
            if (i > 0)
            {
                string s = listBox1.Items[i].ToString();
                string temp = listBox1.Items[i - 1].ToString();
                listBox1.Items[i - 1] = s;
                listBox1.Items[i] = temp;
                listBox1.SelectedIndex = i - 1;
            }
            button3.PerformClick();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int broj = listBox1.Items.Count;
            int sortirano = 1;
            for (int i = 0; i < broj - 1; i++)
            {
                string k1 = listBox1.Items[i].ToString();
                string k2 = listBox1.Items[i + 1].ToString();
                int b1 = Convert.ToInt32(k1);
                int b2 = Convert.ToInt32(k2);
                if (b2 < b1) sortirano = 0;
            }
            if (sortirano == 1)
            {
                MessageBox.Show("aj opet");
                maximum++;
                int k = Convert.ToInt32(label1.Text);
                label1.Text = Convert.ToString(k + 1);
                button1.PerformClick();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int i = listBox1.SelectedIndex;
            if (i >= 0 && i<maximum-1 )
            {
                string s = listBox1.Items[i].ToString();
                string temp = listBox1.Items[i + 1].ToString();
                listBox1.Items[i + 1] = s;
                listBox1.Items[i] = temp;
                listBox1.SelectedIndex = i + 1;
            }
            button3.PerformClick();
        }
    }
}
